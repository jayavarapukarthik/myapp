const Error = ()=>{
    return(
        <>
            <h1>Login Fail : Bad Authentication</h1>
        </>
    )
}
export default Error;